//
//  ViewController.swift
//  Paladugu_CalculatorApp
//
//  Created by Sandhya Paladugu on 9/23/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var finalOutput: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    var firstOperand : Double?
    var operatorVal : String?
    var tempInput : String = ""

    
    @IBAction func numberButtonClick(_ sender: UIButton) {
        if let number = sender.currentTitle {
            //tempInput += number
            finalOutput.text! = "Hello!"
        }
    }
    
    
    @IBAction func opertorClick(_ sender: UIButton) {
        if let tempOperator = sender.currentTitle{
            if let tempNum = Double(tempInput){
                firstOperand = tempNum
                tempInput = ""
                operatorVal = tempOperator
            }
        }
    }
    
    @IBAction func calculateButton(_ sender: UIButton) {
        if let tempOperator = operatorVal, let secondOperand = Double(tempInput){
            var result : Double = 0.0
            //var error : String = ""
            switch tempOperator {
            case "+" :
                result = firstOperand! + secondOperand
            case "-" :
                result = firstOperand! - secondOperand
            case "*" :
                result = firstOperand! * secondOperand
            case "÷" :
                if secondOperand == 0{
                    //error = "Not a number"
                    finalOutput.text = "Not a number"
                    return
                }
                result = firstOperand! / secondOperand
            case "%" :
                result = firstOperand!.truncatingRemainder(dividingBy: secondOperand)
            default : break
            }
            if result.isInfinite || result.isNaN {
                finalOutput.text  = "Not a number"
            }
            else{
                if result.truncatingRemainder(dividingBy: 1.0) == 0{
                    finalOutput.text = String(Int(result))
                }
                else {
                    finalOutput.text = String(result)
                }
            }
        }
    }
    
    @IBAction func allClearButton(_ sender: UIButton) {
        tempInput = ""
        firstOperand = nil
        operatorVal = nil
        finalOutput.text = ""
    }
    @IBAction func clearButton(_ sender: UIButton) {
        tempInput = ""
        finalOutput.text = ""
    }
    
    @IBAction func signChangeButton(_ sender: UIButton) {
        if let number = Double(tempInput) {
            tempInput = String(-number)
            finalOutput.text = tempInput
        }
    }

}
