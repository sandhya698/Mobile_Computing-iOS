//
//  ViewController.swift
//  Paladugu_CalculatorApp
//
//  Created by Sandhya Paladugu on 9/23/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultOutlet: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var number1 = 0.0
    var operat = "+"
    var number2 = 0.0
    var result = 0.0
    var outputString = ""
    
    
    @IBAction func buttonAC(_ sender: Any) {
        resultOutlet.text! = ""
    }
    
    @IBAction func buttonC(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            resultOutlet.text!.removeLast();
        }
    }
    @IBAction func buttonSignChange(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            if (operat == "+"){
                operat = "-"
            }
            else if (operat == "-"){
                operat = "+"
            }
        }
        
    }
    @IBAction func buttonDivision(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            number1 = Double(resultOutlet.text!)!
            operat = "/"
            resultOutlet.text! = ""
        }
    }
    
    @IBAction func buttonSeven(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "7"
    }
    @IBAction func buttonEight(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "8"
    }
    
    @IBAction func buttonNine(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "9"
    }
    @IBAction func buttonMultiplication(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            number1 = Double(resultOutlet.text!)!
            operat = "*"
            resultOutlet.text! = ""
        }
    }
    @IBAction func buttonFour(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "4"
    }
    @IBAction func buttonFive(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "5"
    }
    @IBAction func buttonSix(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "6"
    }
    @IBAction func buttonMinus(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            number1 = Double(resultOutlet.text!)!
            operat = "-"
            resultOutlet.text! = ""
        }
    }
    @IBAction func buttonOne(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "1"
    }
    @IBAction func buttonTwo(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "2"
    }
    @IBAction func buttonThree(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "3"
    }
    @IBAction func ButtonPlus(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            number1 = Double(resultOutlet.text!)!
            operat = "+"
            resultOutlet.text! = ""
        }
    }
    @IBAction func buttonZero(_ sender: Any) {
        resultOutlet.text! = resultOutlet.text! + "0"
    }
    @IBAction func buttonDecimal(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "."
    }
    @IBAction func buttonPercentile(_ sender: Any) {
        if resultOutlet.text!.count > 0{
            number1 = Double(resultOutlet.text!)!
            operat = "%"
            resultOutlet.text! = ""
        }
    }
    @IBAction func buttonEquals(_ sender: Any) {
        number2 = Double(resultOutlet.text!)!
        if operat == "+"{
            result = Double(number1 + number2)
            outputString = String(result)
            if let indexOfDecimal = outputString.firstIndex(of:"."){
                let valueAfterDecimal = outputString[indexOfDecimal..<outputString.endIndex]
                if Double(valueAfterDecimal)! > 0{
                    resultOutlet.text! = outputString
                }
                else{
                    resultOutlet.text! = String(Int(result))
                }
            }
        }
        else if operat == "-"{
            result = Double(number1 - number2)
            outputString = String(result)
            if let indexOfDecimal = outputString.firstIndex(of:"."){
                let valueAfterDecimal = outputString[indexOfDecimal..<outputString.endIndex]
                if Double(valueAfterDecimal)! > 0{
                    resultOutlet.text! = outputString
                }
                else{
                    resultOutlet.text! = String(Int(result))
                }
            }
        }
        else if operat == "*"{
            result = Double(number1 * number2)
            outputString = String(result)
            if let indexOfDecimal = outputString.firstIndex(of:"."){
                let valueAfterDecimal = outputString[indexOfDecimal..<outputString.endIndex]
                if Double(valueAfterDecimal)! > 0{
                    resultOutlet.text! = outputString
                }
                else{
                    resultOutlet.text! = String(Int(result))
                }
            }
        }
        else if operat == "/"{
            if(number2 == 0){
                resultOutlet.text! = "Not a number"
            }
            else{
                result = Double(number1/number2)
                result = round(result*100000)/100000.0
                outputString = String(result)
                if let indexOfDecimal = outputString.firstIndex(of:"."){
                    let valueAfterDecimal = outputString[indexOfDecimal..<outputString.endIndex]
                    if Double(valueAfterDecimal)! > 0{
                        resultOutlet.text! = outputString
                    }
                    else{
                        resultOutlet.text! = String(Int(result))
                    }
                }
            }
        }
        else if operat == "%"{
            if(number2 == 0){   
                resultOutlet.text! = "Not a number"
            }
            else{
                if(number1 > number2){
                    result = number1.truncatingRemainder(dividingBy: number2)
                    result = round(result * 1000)/1000.0
                    resultOutlet.text! = String(result)
                }
                else if(number2 > number1){
                    result = number2.truncatingRemainder(dividingBy: number1)
                    result = round(result * 1000)/1000.0
                    resultOutlet.text! = String(result)
                }
                
            }
        }
    }
}

