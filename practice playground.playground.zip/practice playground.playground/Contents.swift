import UIKit

var name = "sandhya"

print ("My first name is " + name);
print ("I am a student at NorthWest Missouri State University!s");
