import UIKit

var greeting = "Hello, playground"

print("Hello, world!")

print(greeting)

print(greeting, " NWMSU", terminator : "-")

print("the statement is \(greeting)") //string interpolation

print("""
    Hello, All
    Sandhya's playground!
""")

print(greeting, "sandhya", 10, separator : "-")

var num = 10

print(num, "here is the output")

print("sandhya","lalli",10.5,5, separator : "/")

var name : String = "sandhya"
name = "sandy"
print("My name is \(name)")

let name1 : String = "sandhya"
print("My name is \(name1)")
